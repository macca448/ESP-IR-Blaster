// replace the ssid and password with what your WiFi Router uses
const char* ssid     = "Your_SSID";
const char* password = "Your_Password";
